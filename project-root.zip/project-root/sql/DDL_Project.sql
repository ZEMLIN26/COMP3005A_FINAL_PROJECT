-- this file containes the DDL statements for the final project of COMP3005
DROP SEQUENCE IF EXISTS emp_trainer_id_seq;
DROP TABLE IF EXISTS Administrative_Staff cascade;
DROP TABLE IF EXISTS Members cascade;
DROP TABLE IF EXISTS Health_Metrics;
DROP TABLE IF EXISTS Trainers cascade;
DROP TABLE IF EXISTS Personal_Training;
DROP TABLE IF EXISTS Availabilities cascade;
DROP TABLE IF EXISTS Individual_Training_Sessions;
DROP TABLE IF EXISTS Group_Fitness_Classes cascade;
DROP TABLE IF EXISTS Class_Enrolment;
DROP TABLE IF EXISTS Room cascade; 
DROP TABLE IF EXISTS Room_Booking;
DROP VIEW IF EXISTS Member_info;
DROP INDEX IF EXISTS idx_trainer_availabilities_date;



-- create a sequence to generate employee IDs
-- trainer_id and employee_id will use this sequence, so theri values do not overlap
CREATE SEQUENCE emp_trainer_id_seq
    AS INT
    START WITH 1
    INCREMENT BY 1;

CREATE TABLE Administrative_Staff(
    employee_id     INT PRIMARY KEY,
    first_name      VARCHAR(20) NOT NULL,
    last_name       VARCHAR(20) NOT NULL,
    gender          VARCHAR(1) NOT NULL CHECK (gender IN ('M', 'F')),
    date_of_birth   DATE NOT NULL,
    email           VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Members(
    email	             VARCHAR(50) PRIMARY KEY,
    first_name           VARCHAR(20) NOT NULL,
    last_name            VARCHAR(20) NOT NULL,
    gender               VARCHAR(1) NOT NULL CHECK (gender IN ('M', 'F')),
    date_of_birth        DATE NOT NULL,
    weight_goal_kg       NUMERIC(5,2) NOT NULL CHECK (weight_goal_kg BETWEEN 0 AND 1000),
    body_fat_goal_pct    NUMERIC(4,2) NOT NULL CHECK (body_fat_goal_pct BETWEEN 0 AND 100)
);

CREATE TABLE Health_Metrics(
    email           VARCHAR(50),
    height_cm       NUMERIC(5,2) NOT NULL CHECK (height_cm BETWEEN 30 AND 300),
    weight_kg       NUMERIC(5,2) NOT NULL CHECK (weight_kg BETWEEN 0 AND 1000),
    heart_rate      INT NOT NULL CHECK (heart_rate BETWEEN 0 AND 300),
    date_of_record  Date NOT NULL DEFAULT CURRENT_DATE,
    PRIMARY KEY (email, date_of_record),
    FOREIGN KEY (email)
        REFERENCES Members(email)
);

CREATE TABLE Trainers(
    trainer_id      INT PRIMARY KEY,
    first_name      VARCHAR(20) NOT NULL,
    last_name       VARCHAR(20) NOT NULL,
    gender          VARCHAR(1) NOT NULL CHECK (gender IN ('M', 'F')),
    date_of_birth   DATE NOT NULL,
    email           VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Personal_Training(
    trainer_id      INT PRIMARY KEY,
    member          VARCHAR(50) NOT NULL, 
    FOREIGN KEY (trainer_id)
        REFERENCES Trainers(trainer_id),
    FOREIGN KEY (member)
        REFERENCES Members(email)
);

CREATE TABLE Availabilities(
    trainer_id      INT NOT NULL,
    date_of_record  DATE NOT NULL CHECK (date_of_record >= CURRENT_DATE),
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    PT_or_GF        VARCHAR(2) NOT NULL CHECK (PT_or_GF IN ('PT', 'GF')),
    isBooked        BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (trainer_id)
        REFERENCES Trainers(trainer_id)
);

CREATE TABLE Room(
    room_number     INT PRIMARY KEY,
    capacity        INT NOT NULL CHECK (capacity > 0)
);

CREATE TABLE Individual_Training_Sessions(
    trainer_id      INT NOT NULL,
    date_of_record  DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    capacity        INT NOT NULL CHECK (capacity >= 0),
    --  room_number can be NULL if no room is assigned yet
    room_number     INT,
    member          VARCHAR(50) NOT NULL,
    PRIMARY KEY (trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (trainer_id, date_of_record, start_time,end_time)
        REFERENCES Availabilities(trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (room_number)
        REFERENCES Room(room_number),
    FOREIGN KEY (member)
        REFERENCES Members(email)
);


CREATE TABLE Group_Fitness_Classes(
    trainer_id      INT NOT NULL,
    date_of_record  DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    class_name      VARCHAR(50) NOT NULL,
    capacity        INT NOT NULL CHECK (capacity >= 0),
    room_number     INT,
    PRIMARY KEY (trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (trainer_id, date_of_record, start_time,end_time)
        REFERENCES Availabilities(trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (room_number)
        REFERENCES Room(room_number)
);  

CREATE TABLE Class_Enrolment(
    trainer_id      INT NOT NULL,
    date_of_record  DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    member          VARCHAR(50) NOT NULL,
    PRIMARY KEY (trainer_id, date_of_record, start_time, end_time, member),
    FOREIGN KEY (trainer_id, date_of_record, start_time,end_time)
        REFERENCES Group_Fitness_Classes(trainer_id, date_of_record, start_time, end_time),
    FOREIGN KEY (member)
        REFERENCES Members(email)
);


CREATE TABLE Room_Booking(
    room_number     INT NOT NULL,
    date_of_record  DATE NOT NULL,
    start_time      TIME NOT NULL,
    end_time        TIME NOT NULL,
    isBooked        BOOLEAN NOT NULL DEFAULT FALSE,
    staff           INT,
    trainer         INT,
    PRIMARY KEY (room_number, date_of_record, start_time, end_time),
    FOREIGN KEY (room_number)
        REFERENCES Room(room_number),
    FOREIGN KEY (staff)
        REFERENCES Administrative_Staff(employee_id),
    FOREIGN KEY (trainer)
        REFERENCES Trainers(trainer_id)
);

-- Index: Trainer Availabilities Date
CREATE INDEX idx_trainer_availabilities_date
    ON Availabilities(trainer_id, date_of_record, start_time);


--VIEW: Member_info--Most recent health metrics, fitness goals, upcoming individual training session and group fitness classes of Members
CREATE VIEW Member_info AS
    SELECT m.email, m.first_name, m.last_name, m.gender, m.date_of_birth, m.weight_goal_kg, m.body_fat_goal_pct,
    hm.height_cm, hm.weight_kg, hm.heart_rate, hm.date_of_record,
    its.trainer_id AS its_trainer, its.date_of_record AS its_date, its.start_time AS its_start, its.end_time AS its_end, its.room_number AS its_room,  
    gfc.trainer_id AS gfc_trainer, gfc.class_name, gfc.date_of_record AS gfc_date, gfc.start_time AS gfc_start, gfc.end_time AS gfc_end, gfc.room_number AS gfc_room
    FROM Members m, Health_Metrics hm, Individual_Training_Sessions its, Group_Fitness_Classes gfc, Class_Enrolment ce
    WHERE m.email = hm.email AND hm.date_of_record = (
        SELECT MAX(date_of_record)
        FROM Health_Metrics
        WHERE email = m.email
    ) 
    -- this will find the most recent personal training session for the member
    AND m.email = its.member
    AND (its.date_of_record, its.start_time) = (
        SELECT date_of_record, start_time
        FROM Individual_Training_Sessions
        WHERE (date_of_record, start_time) >= (CURRENT_DATE, LOCALTIME)
        ORDER BY date_of_record ASC, start_time ASC
        LIMIT 1
        )
    -- this will find the most recent group fitness classes for the member (might with different trainers)
    AND m.email = ce.member
    AND (gfc.date_of_record, gfc.start_time) IN (
        SELECT date_of_record, start_time
        FROM Class_Enrolment
        WHERE (date_of_record, start_time) >= (CURRENT_DATE, LOCALTIME)
        ORDER BY date_of_record ASC, start_time ASC
        )
    -- this make sure the soonest fitness classes are shown first
    ORDER BY m.email ASC, gfc_date ASC, gfc_start ASC;

    
-- add a trigger after insertion to Individual_Training_Sessions to update isBooked in Availabilities
CREATE OR REPLACE FUNCTION update_availability_booked_status()
RETURNS TRIGGER 
AS $$
BEGIN
    UPDATE Availabilities
    SET isBooked = TRUE
    WHERE trainer_id = NEW.trainer_id
      AND date_of_record = NEW.date_of_record
      AND start_time = NEW.start_time
      AND end_time   = NEW.end_time;
    RETURN NEW;
END;
$$Language plpgsql;

CREATE TRIGGER trg_update_availability_booked_status
AFTER INSERT ON Individual_Training_Sessions
FOR EACH ROW
EXECUTE FUNCTION update_availability_booked_status();

-- add a trigger after insertion to Group_Fitness_Classes to update isBooked in Availabilities
CREATE OR REPLACE FUNCTION update_gfc_availability_booked_status()
RETURNS TRIGGER 
AS $$
BEGIN
    UPDATE Availabilities
    SET isBooked = TRUE
    WHERE trainer_id = NEW.trainer_id
      AND date_of_record = NEW.date_of_record
      AND start_time = NEW.start_time
      AND end_time   = NEW.end_time;
    RETURN NEW;
END;
$$Language plpgsql;

CREATE TRIGGER trg_update_gfc_availability_booked_status
AFTER INSERT ON Group_Fitness_Classes
FOR EACH ROW
EXECUTE FUNCTION update_gfc_availability_booked_status();
