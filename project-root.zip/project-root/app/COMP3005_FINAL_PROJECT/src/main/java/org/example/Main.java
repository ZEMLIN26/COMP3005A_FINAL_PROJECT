package org.example;
import java.sql.*;
import java.lang.ClassNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String url="jdbc:postgresql://localhost:5432/Health and Fitness Club Management System";
        String user="postgres";
        String password="postgres";

        try{
            Class.forName("org.postgresql.Driver");
            Connection connection=DriverManager.getConnection(url,user,password);
            //create a scanner object
            Scanner input = new Scanner(System.in);
            if (connection !=null){
                System.out.println("Connected to the postgresSQL server successfully.");

                //application logics

                while (true){
                    System.out.println("Please choose your role:");
                    System.out.println("1. Members");
                    System.out.println("2. Trainers");
                    System.out.println("3. Administrative Staff");
                    System.out.println("4. Exit the application");
                    int choice=input.nextInt();
                    //clear the trailing newline
                    input.nextLine();
                    if (choice==1){
                        while (true){
                            System.out.println("Please choose your operation:");
                            System.out.println("1. User Registration");
                            System.out.println("2. Log Health Metrics");
                            System.out.println("3. Individual Training Session Scheduling");
                            System.out.println("4. Group Fitness Class Scheduling");
                            System.out.println("5. Exit the member");;
                            int operation=input.nextInt();
                            //clear the trailing newline
                            input.nextLine();

                            if (operation==1){
                                //Email is the primary key
                                System.out.println("Email:");
                                String email=input.nextLine();
                                userRegistration(connection,input,email);
                            }else if (operation==2){
                                System.out.println("Email:");
                                String email=input.nextLine();
                                logHealthMetrics(connection,input,email);
                            }else if (operation==3){
                                System.out.println("Email:");
                                String email=input.nextLine();
                                itsBooking(connection,input,email);
                            }else if (operation==4){
                                System.out.println("Email:");
                                String email=input.nextLine();
                                gfcBooking(connection,input,email);
                            }else if (operation==5){
                                break;
                            }else{
                                System.out.println("Please choose between 1 to 5.");
                            }
                        }
                    }else if (choice==2){
                        while (true) {
                            System.out.println("Please choose the operation you want to perform as a trainer:");
                            System.out.println("1. Set an availability");
                            System.out.println("2. View the upcoming schedule");
                            System.out.println("3. Exit the trainer");
                            int option=input.nextInt();
                            input.nextLine();
                            if (option==1){
                                while (true){
                                    System.out.println("What is your trainer ID?");
                                    int id = input.nextInt();
                                    input.nextLine();
                                    //check if the trainer exist
                                    String existSQL = "SELECT EXISTS (SELECT 1 FROM Trainers WHERE trainer_ID=?)";
                                    try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
                                        pst.setInt(1, id);
                                        ResultSet r = pst.executeQuery();
                                        boolean exists = false;
                                        if (r.next()) {
                                            exists = r.getBoolean(1); // <- read the EXISTS result
                                        }
                                        r.close();
                                        if (!exists) {
                                            System.out.println("Trainer does not exist, please register the trainer");
                                            System.out.println("First Name: ");
                                            String firstName = input.nextLine();
                                            System.out.println("Last Name:");
                                            String lastName = input.nextLine();
                                            System.out.println("Gender (M/F):");
                                            String gender = input.nextLine();
                                            System.out.println("Date of Birth (yyyy-mm-dd):");
                                            String dateBirth = input.nextLine();
                                            System.out.println("Email: ");
                                            String email = input.nextLine();

                                            String insertTrainerSQL = "INSERT INTO Trainers (first_name,last_name,gender,date_of_birth,email) VALUES (?,?,?,?,?)";
                                            PreparedStatement ps = connection.prepareStatement(insertTrainerSQL);
                                            ps.setString(1, firstName);
                                            ps.setString(2, lastName);
                                            ps.setString(3, gender);
                                            ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                                            ps.setString(5, email);
                                            ps.executeUpdate();
                                            System.out.println("Insertion to the Trainer is successful!");
                                            continue;
                                        }
                                        setAvailability(connection, input, id);
                                        break;
                                    } catch (SQLException e) {
                                        System.out.println("Failed to set the availability.");
                                        e.printStackTrace();
                                    }
                                }
                            }else if (option==2){
                                //dashboard
                                while (true){
                                    System.out.println("What is your trainer ID?");
                                    int id = input.nextInt();
                                    input.nextLine();
                                    //check if the trainer exist
                                    String existSQL = "SELECT EXISTS (SELECT 1 FROM Trainers WHERE trainer_ID=?)";
                                    try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
                                        pst.setInt(1, id);
                                        ResultSet r = pst.executeQuery();
                                        boolean exists = false;
                                        if (r.next()) {
                                            exists = r.getBoolean(1); // <- read the EXISTS result
                                        }
                                        r.close();
                                        if (!exists) {
                                            System.out.println("Trainer does not exist, please register the trainer");
                                            System.out.println("First Name: ");
                                            String firstName = input.nextLine();
                                            System.out.println("Last Name:");
                                            String lastName = input.nextLine();
                                            System.out.println("Gender (M/F):");
                                            String gender = input.nextLine();
                                            System.out.println("Date of Birth (yyyy-mm-dd):");
                                            String dateBirth = input.nextLine();
                                            System.out.println("Email: ");
                                            String email = input.nextLine();

                                            String insertTrainerSQL = "INSERT INTO Trainers (first_name,last_name,gender,date_of_birth,email) VALUES (?,?,?,?,?)";
                                            PreparedStatement ps = connection.prepareStatement(insertTrainerSQL);
                                            ps.setString(1, firstName);
                                            ps.setString(2, lastName);
                                            ps.setString(3, gender);
                                            ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                                            ps.setString(5, email);
                                            ps.executeUpdate();
                                            System.out.println("Insertion to the Trainer is successful!");
                                            continue;
                                        }
                                        scheduleView(connection, input, id);
                                        break;
                                    } catch (SQLException e) {
                                        System.out.println("Failed to set the availability.");
                                        e.printStackTrace();
                                    }
                                }
                            }else if (option==3){
                                break;
                            }else{
                                System.out.println("Please enter a number between 1 to 3.");
                            }
                        }
                    }else if (choice==3){
                        while (true) {
                            System.out.println("Please choose the operation you want:");
                            System.out.println("1. Book a room for a individual training session or a group fitness class");
                            System.out.println("2. Define class");
                            System.out.println("3. Exit the administrative staff");
                            int option = input.nextInt();
                            input.nextLine();
                            if (option == 1){
                                while (true){
                                    System.out.println("What is your employee ID?");
                                    int id = input.nextInt();
                                    input.nextLine();
                                    //check if the administrative employee exist
                                    String existSQL = "SELECT EXISTS (SELECT 1 FROM Administrative_Staff WHERE employee_ID=?)";
                                    try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
                                        pst.setInt(1, id);
                                        ResultSet r = pst.executeQuery();
                                        boolean exists = false;
                                        if (r.next()) {
                                            exists = r.getBoolean(1); // <- read the EXISTS result
                                        }
                                        r.close();
                                        if (!exists) {
                                            System.out.println("Administrative staff does not exist, please register the administrative staff");
                                            System.out.println("First Name: ");
                                            String firstName = input.nextLine();
                                            System.out.println("Last Name:");
                                            String lastName = input.nextLine();
                                            System.out.println("Gender (M/F):");
                                            String gender = input.nextLine();
                                            System.out.println("Date of Birth (yyyy-mm-dd):");
                                            String dateBirth = input.nextLine();
                                            System.out.println("Email: ");
                                            String email = input.nextLine();

                                            String insertTrainerSQL = "INSERT INTO Administrative_Staff (first_name,last_name,gender,date_of_birth,email) VALUES (?,?,?,?,?)";
                                            PreparedStatement ps = connection.prepareStatement(insertTrainerSQL);
                                            ps.setString(1, firstName);
                                            ps.setString(2, lastName);
                                            ps.setString(3, gender);
                                            ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                                            ps.setString(5, email);
                                            ps.executeUpdate();
                                            System.out.println("Insertion to the Administrative_Staff is successful!");
                                            continue;
                                        }
                                        bookRoom(connection, input, id);
                                        break;
                                    } catch (SQLException e) {
                                        System.out.println("Failed to set the availability.");
                                        e.printStackTrace();
                                    }
                                }
                            }else if (option == 2) {
                                while (true) {
                                    System.out.println("What is your employee ID?");
                                    int id = input.nextInt();
                                    input.nextLine();
                                    //check if the administrative employee exist
                                    String existSQL = "SELECT EXISTS (SELECT 1 FROM Administrative_Staff WHERE employee_ID=?)";
                                    try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
                                        pst.setInt(1, id);
                                        ResultSet r = pst.executeQuery();
                                        boolean exists = false;
                                        if (r.next()) {
                                            exists = r.getBoolean(1); // <- read the EXISTS result
                                        }
                                        r.close();
                                        if (!exists) {
                                            System.out.println("Administrative staff does not exist, please register the administrative staff");
                                            System.out.println("First Name: ");
                                            String firstName = input.nextLine();
                                            System.out.println("Last Name:");
                                            String lastName = input.nextLine();
                                            System.out.println("Gender (M/F):");
                                            String gender = input.nextLine();
                                            System.out.println("Date of Birth (yyyy-mm-dd):");
                                            String dateBirth = input.nextLine();
                                            System.out.println("Email: ");
                                            String email = input.nextLine();

                                            String insertTrainerSQL = "INSERT INTO Administrative_Staff (first_name,last_name,gender,date_of_birth,email) VALUES (?,?,?,?,?)";
                                            PreparedStatement ps = connection.prepareStatement(insertTrainerSQL);
                                            ps.setString(1, firstName);
                                            ps.setString(2, lastName);
                                            ps.setString(3, gender);
                                            ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                                            ps.setString(5, email);
                                            ps.executeUpdate();
                                            System.out.println("Insertion to the Administrative_Staff is successful!");
                                            continue;
                                        }
                                        defineClass(connection, input, id);
                                        break;
                                    } catch (SQLException e) {
                                        System.out.println("Failed to set the availability.");
                                        e.printStackTrace();
                                    }
                                }
                            }else if (option == 3) {
                                break;
                            }else {
                                System.out.println("Please enter a number beween 1 to 3.");
                            }
                        }
                    }else if (choice==4){
                        break;
                    }else{
                        System.out.println("Please choose between 1 to 4.");
                    }
                }

            }else{
                System.out.println("Failed to connect to the postgresSQL server.");
            }
            input.close();
            connection.close();
            System.out.println("Disconnected from the server.");

        }catch(ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }

    }

    public static void userRegistration(Connection connection, Scanner input, String email){
        String querySQL = "SELECT EXISTS (SELECT 1 FROM Members WHERE email=?)";
        try (PreparedStatement pstmt=connection.prepareStatement(querySQL)){
            pstmt.setString(1,email);
            ResultSet rs = pstmt.executeQuery();
            boolean exists=false;
            if (rs.next()) {
                exists = rs.getBoolean(1); // <- read the EXISTS result
            }

            rs.close();

            if (exists) {
                //this means the user already exists
                System.out.println("The user already exists. Do you want to update the information?");
                System.out.println("1. Update the information");
                System.out.println("2. Exit the registration");
                int choice = input.nextInt();
                //clear the trailing newline
                input.nextLine();

                if (choice == 1) {
                    System.out.println("First Name:");
                    String firstName = input.nextLine();
                    System.out.println("Last Name:");
                    String lastName = input.nextLine();
                    System.out.println("Gender (M/F): ");
                    String gender = input.nextLine();
                    System.out.println("Date of Birth:");
                    String dateBirth = input.nextLine();
                    System.out.println("Weight Goal (kg):");
                    float weightGoal = input.nextFloat();
                    input.nextLine();
                    System.out.println("Body Fat Goal (%):");
                    float bodyFat = input.nextFloat();
                    input.nextLine();
                    String updateSQL = "UPDATE Members SET first_name=?, last_name=?, gender=?, date_of_birth=?, weight_goal_kg=?, body_fat_pct=? WHERE email=?";
                    try (PreparedStatement ps = connection.prepareStatement(querySQL)) {
                        ps.setString(1, firstName);
                        ps.setString(2, lastName);
                        ps.setString(3, gender);
                        ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                        ps.setFloat(5, weightGoal);
                        ps.setFloat(6, bodyFat);
                        ps.setString(7, email);
                        ps.executeUpdate();
                        System.out.println("Update is successful.");
                    } catch (SQLException e) {
                        System.out.println("Failed to update.");
                        e.printStackTrace();
                    }
                } else if (choice == 2) {
                    return;
                } else {
                    System.out.println("Please enter the number between 1 and 2.");
                }
            }else{
            //this means the user does not exist
                System.out.println("First Name:");
                String firstName = input.nextLine();
                System.out.println("Last Name:");
                String lastName = input.nextLine();
                System.out.println("Gender (M/F): ");
                String gender = input.nextLine();
                System.out.println("Date of Birth:");
                String dateBirth = input.nextLine();
                System.out.println("Weight Goal (kg):");
                float weightGoal = input.nextFloat();
                input.nextLine();
                System.out.println("Body Fat Goal (%):");
                float bodyFat = input.nextFloat();
                input.nextLine();
                String insertSQL = "INSERT INTO Members VALUES(?,?,?,?,?,?,?)";
                try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
                    ps.setString(1, email);
                    ps.setString(2, firstName);
                    ps.setString(3, lastName);
                    ps.setString(4, gender);
                    ps.setDate(5, java.sql.Date.valueOf(dateBirth));
                    ps.setFloat(6, weightGoal);
                    ps.setFloat(7, bodyFat);
                    ps.executeUpdate();
                    System.out.println("Insertion is successful.");
                } catch (SQLException e) {
                    System.out.println("Failed to insert.");
                    e.printStackTrace();
                }
            }
        } catch(SQLException e) {
            System.out.println("Registration failed.");
            e.printStackTrace();
        }
    }

    public static void logHealthMetrics(Connection connection, Scanner input, String email){
        String querySQL = "SELECT EXISTS (SELECT 1 FROM Members WHERE email=?)";
        try (PreparedStatement pstmt=connection.prepareStatement(querySQL)){
            pstmt.setString(1,email);
            ResultSet rs = pstmt.executeQuery();
            boolean exists=false;
            if (rs.next()) {
                exists = rs.getBoolean(1); // <- read the EXISTS result
            }
            rs.close();

            if (exists) {
                //user exists
                System.out.println("Height (cm):");
                float height = input.nextFloat();
                input.nextLine();
                System.out.println("Weight (kg):");
                float weight = input.nextFloat();
                input.nextLine();
                System.out.println("Heart Rate: ");
                int heartRate = input.nextInt();
                input.nextLine();

                String insertSQL = "INSERT INTO Health_Metrics (email, height_cm, weight_kg, heart_rate)VALUES (?,?,?,?)";
                try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
                    ps.setString(1, email);
                    ps.setFloat(2, height);
                    ps.setFloat(3, weight);
                    ps.setInt(4, heartRate);
                    ps.executeUpdate();
                    System.out.println("Insertion of a new record of health metrics is successful.");
                } catch (SQLException e) {
                    System.out.println("Failed to insert a new record of health metrics.");
                    e.printStackTrace();
                }
            }else{
              System.out.println("The user does not exist. Do you want to register the user?");
              System.out.println("1. Register the user");
              System.out.println("2. Exit without register the user and update the health metrics.");
              int choice=input.nextInt();
              input.nextLine();
              if (choice==1){
                  System.out.print("Redirecting to USER REGISTRATION");
                  userRegistration(connection,input,email);
              }else if (choice==2){
                  System.out.println("Exit without register the user or logging the health metrics.");
                  return;
              }else{
                  System.out.println("Please enter the number between 1 and 2.");
              }
            }
        } catch(SQLException e) {
            System.out.println("Update to he health metrics failed.");
            e.printStackTrace();
        }
    }

    public static void itsBooking(Connection connection, Scanner input, String email) {
        //check if the user exists
        String existSQL = "SELECT EXISTS (SELECT 1 FROM Members WHERE email=?)";
        try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
            pst.setString(1, email);
            ResultSet r = pst.executeQuery();
            boolean exists = false;
            if (r.next()) {
                exists = r.getBoolean(1); // <- read the EXISTS result
            }
            r.close();
            if (!exists) {
                System.out.println("User does not exist, please register the user first");
                userRegistration(connection, input, email);
            }

            while (true) {
                System.out.println("Do you want to book a new indiviudal training session?");
                System.out.println("1. Book a new session");
                System.out.println("2. Exit the booking.");
                int choice = input.nextInt();
                input.nextLine();
                if (choice == 1) {
                    String querySQL = "SELECT trainer_ID FROM Personal_Training WHERE member=?";
                    try (PreparedStatement pstmt = connection.prepareStatement(querySQL)) {
                        pstmt.setString(1, email);
                        ResultSet rs = pstmt.executeQuery();
                        if (rs.next()) {
                            //the member has a personal trainer, get the trainer_ID
                            int trainerID = rs.getInt("trainer_id");
                            String searchSQL = "SELECT * FROM Availabilities WHERE trainer_ID=? AND date_of_record>=? AND PT_or_GF=? AND isBooked=?";
                            String today = LocalDate.now().toString();
                            try (PreparedStatement ps = connection.prepareStatement(searchSQL)) {
                                ps.setInt(1, trainerID);
                                ps.setDate(2, java.sql.Date.valueOf(today));
                                ps.setString(3, "PT");
                                ps.setBoolean(4, false);
                                ResultSet trainerAvailability = ps.executeQuery();
                                int index = 0;
                                ArrayList<PreparedStatement> insertList = new ArrayList<>();
//                                ArrayList<PreparedStatement> updateList = new ArrayList<>();
                                //list all the availabilities of the personal trainer
                                while (trainerAvailability.next()) {
                                    String dateRecord = trainerAvailability.getString("date_of_record");
                                    String startTime = trainerAvailability.getString("start_time");
                                    String endTime = trainerAvailability.getString("end_time");
                                    System.out.println(String.format("%d. TrainerID: %d, Date: %s, Start Time: %s, End Time: %s", index + 1, trainerID, dateRecord, startTime, endTime));
                                    //after insertion, room number will be null
                                    //change this into preparestatement
                                    String insertSQL = "INSERT INTO Individual_Training_Sessions (trainer_id, date_of_record, start_time, end_time, capacity, member) VALUES (?, ?, ?, ?, 2,?)";
                                    PreparedStatement prepareInsert = connection.prepareStatement(insertSQL);
                                    prepareInsert.setInt(1, trainerID);
                                    prepareInsert.setDate(2, java.sql.Date.valueOf(dateRecord));
                                    prepareInsert.setTime(3, java.sql.Time.valueOf(startTime));
                                    prepareInsert.setTime(4, java.sql.Time.valueOf(endTime));
                                    prepareInsert.setString(5, email);
                                    insertList.add(prepareInsert);
//
//                                    String updateSQL = "UPDATE Availabilities SET isBooked=? WHERE trainer_id=? AND date_of_record=? AND start_time=? AND end_time=?";
//                                    PreparedStatement prepareUpdate = connection.prepareStatement(updateSQL);
//                                    prepareUpdate.setBoolean(1, true);
//                                    prepareUpdate.setInt(2, trainerID);
//                                    prepareUpdate.setDate(3, java.sql.Date.valueOf(dateRecord));
//                                    prepareUpdate.setTime(4, java.sql.Time.valueOf(startTime));
//                                    prepareUpdate.setTime(5, java.sql.Time.valueOf(endTime));
//                                    updateList.add(prepareUpdate);

                                    index++;
                                }
                                System.out.println("Please choose the availability you want to book. Type 7 to exit");
                                int option = input.nextInt();
                                input.nextLine();
                                if (option==7){
                                    break;
                                }
                                //insertion to the ITS table
                                insertList.get(option - 1).executeUpdate();

                                //update to the Availability table
//                                updateList.get(option - 1).executeQuery();

                                trainerAvailability.close();
                                for (int k = 0; k < insertList.size(); k++) {
                                    insertList.get(k).close();
//                                    updateList.get(k).close();
                                }

                                System.out.println("Individual training session is booked successful. Please ask an administrative staff to book a room.");
                            } catch (SQLException e) {
                                System.out.println("Failed to book an individual training session.");
                                e.printStackTrace();
                            }
                        } else {
                            //trainer does not exist
                            //need to choose a trainer first
                            String trainerFinderSQL = "SELECT t.* FROM Trainers t, Availabilities a WHERE t.trainer_ID=a.trainer_ID AND a.PT_or_GF='PT' AND a.isBooked=false AND a.date_of_record >= CURRENT_DATE";

                            Statement findTrainerStatement = connection.createStatement();
                            findTrainerStatement.executeQuery(trainerFinderSQL);
                            ResultSet result = findTrainerStatement.getResultSet();
                            int order = 0;
                            ArrayList<Integer> trainerIDList = new ArrayList<>();
                            while (result.next()) {
                                //list the trainers
                                int trainer = result.getInt("trainer_ID");
                                String firstName = result.getString("first_name");
                                String lastName = result.getString("last_name");
                                String gender = result.getString("gender");
                                System.out.println(String.format("%d . Trainer ID: %s, First Name: %s, Last Name: %s", order + 1, trainer, firstName, lastName));
                                trainerIDList.add(trainer);
                                order++;
                            }
                            result.close();
                            System.out.println("Which trainer do you want to book an appointment with?");
                            int selection = input.nextInt();
                            input.nextLine();
                            int trainerID = trainerIDList.get(selection - 1);

                            String searchSQL = "SELECT * FROM Availabilities WHERE trainer_ID=? AND date_of_record>=? AND PT_or_GF=? AND isBooked=?";
                            String today = LocalDate.now().toString();
                            try (PreparedStatement ps = connection.prepareStatement(searchSQL)) {
                                ps.setInt(1, trainerID);
                                ps.setDate(2, java.sql.Date.valueOf(today));
                                ps.setString(3, "PT");
                                ps.setBoolean(4, false);
                                ResultSet trainerAvailability = ps.executeQuery();
                                int index = 0;
                                ArrayList<PreparedStatement> insertList = new ArrayList<>();
//                                ArrayList<PreparedStatement> updateList = new ArrayList<>();
                                //list all the availabilities of the personal trainer
                                while (trainerAvailability.next()) {
                                    String dateRecord = trainerAvailability.getString("date_of_record");
                                    String startTime = trainerAvailability.getString("start_time");
                                    String endTime = trainerAvailability.getString("end_time");
                                    System.out.println(String.format("%d . TrainerID: %d, Date: %s, Start Time: %s, End Time: %s", index + 1, trainerID, dateRecord, startTime, endTime));

                                    //after insertion, room number will be null
                                    //change this into preparestatement
                                    String insertSQL = "INSERT INTO Individual_Training_Sessions (trainer_id, date_of_record, start_time, end_time, capacity, member) VALUES (?, ?, ?, ?, 2,?)";
                                    PreparedStatement prepareInsert = connection.prepareStatement(insertSQL);
                                    prepareInsert.setInt(1, trainerID);
                                    prepareInsert.setDate(2, java.sql.Date.valueOf(dateRecord));
                                    prepareInsert.setTime(3, java.sql.Time.valueOf(startTime));
                                    prepareInsert.setTime(4, java.sql.Time.valueOf(endTime));
                                    prepareInsert.setString(5, email);
                                    insertList.add(prepareInsert);

//                                    String updateSQL = "UPDATE Availabilities SET isBooked=? WHERE trainer_id=? AND date_of_record=? AND start_time=? AND end_time=?";
//                                    PreparedStatement prepareUpdate = connection.prepareStatement(updateSQL);
//                                    prepareUpdate.setBoolean(1, true);
//                                    prepareUpdate.setInt(2, trainerID);
//                                    prepareUpdate.setDate(3, java.sql.Date.valueOf(dateRecord));
//                                    prepareUpdate.setTime(4, java.sql.Time.valueOf(startTime));
//                                    prepareUpdate.setTime(5, java.sql.Time.valueOf(endTime));
//                                    updateList.add(prepareUpdate);

                                    index++;
                                }
                                System.out.println("Please choose the availability you want to book.");
                                int option = input.nextInt();
                                input.nextLine();
//                            //insertion to the ITS table
//                            Statement insertStatement = connection.createStatement();
//                            insertStatement.executeQuery(insertList.get(option - 1));
//                            //update to the Availability table
//                            Statement updateStatement = connection.createStatement();
//                            updateStatement.executeQuery(updateList.get(option - 1));

                                //insertion to the ITS table
                                insertList.get(option - 1).executeUpdate();

                                //update to the Availability table
//                                updateList.get(option - 1).executeUpdate();

                                trainerAvailability.close();
                                for (int k = 0; k < insertList.size(); k++) {
                                    insertList.get(k).close();
//                                    updateList.get(k).close();
                                }

                                //insert a row to Personal_Training table
                                String insertPTSQL = "INSERT INTO Personal_Training (trainer_id, member) VALUES (?, ?)" + "ON CONFLICT (trainer_id) DO NOTHING";;

                                try (PreparedStatement psPT = connection.prepareStatement(insertPTSQL)) {
                                    psPT.setInt(1, trainerID);
                                    psPT.setString(2, email);
                                    psPT.executeUpdate();
                                }

                                trainerAvailability.close();

                                System.out.println("Individual training session is booked successful. Please ask an administrative staff to book a room.");

                            } catch (SQLException e) {
                                System.out.println("Failed to book an individual training session.");
                                e.printStackTrace();
                            }
                            rs.close();
                        }
                    } catch (SQLException e) {
                        System.out.println("Failed to book an individual training session.");
                        e.printStackTrace();
                    }
                } else if (choice == 2) {
                    break;
                } else {
                    System.out.println("Please enter a number between 1 and 3.");
                }
            }
        }catch (SQLException e) {
            System.out.println("Failed to book an individual training session.");
            e.printStackTrace();
    }
        }
    public static void gfcBooking(Connection connection, Scanner input, String email) {
        //check if the user exists
        String existSQL = "SELECT EXISTS (SELECT 1 FROM Members WHERE email=?)";
        try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
            pst.setString(1, email);
            ResultSet r = pst.executeQuery();
            boolean exists = false;
            if (r.next()) {
                exists = r.getBoolean(1); // <- read the EXISTS result
            }
            r.close();
            if (!exists) {
                System.out.println("User does not exist, please register the user first");
                userRegistration(connection, input, email);
            }

            String querySQL = "SELECT * FROM Group_Fitness_Classes WHERE date_of_record>=?";
            String today = LocalDate.now().toString();
            try (PreparedStatement ps = connection.prepareStatement(querySQL)) {
                ps.setDate(1, java.sql.Date.valueOf(today));
                ResultSet rs = ps.executeQuery();
                ArrayList<PreparedStatement> checkSumSQLList = new ArrayList<>();
                ArrayList<PreparedStatement> insertSQLList = new ArrayList<>();
                ArrayList<Integer> capacityList = new ArrayList<>();
                int index = 0;
                while (rs.next()) {
                    int trainerID = rs.getInt("trainer_ID");
                    String dateRecord = rs.getString("date_of_record");
                    String startTime = rs.getString("start_time");
                    String endTime = rs.getString("end_time");
                    String className = rs.getString("class_name");
                    int capacity = rs.getInt("capacity");
                    int roomNumber = rs.getInt("room_number");
                    System.out.println(String.format("%d . Trainer ID: %s, Date of Record: %s, Start Time: %s, End Time: %s, Class Name: %s, Capacity: %d, Room Number: %d", index + 1, trainerID, dateRecord, startTime, endTime, className, capacity, roomNumber));

                    String checkSumSQL = "SELECT COUNT(*) AS Sum FROM Class_Enrolment WHERE trainer_id=? AND date_of_record=? AND start_time=? AND end_time=?";
                    PreparedStatement prepareCheckSum = connection.prepareStatement(checkSumSQL);
                    prepareCheckSum.setInt(1, trainerID);
                    prepareCheckSum.setDate(2, java.sql.Date.valueOf(dateRecord));
                    prepareCheckSum.setTime(3, java.sql.Time.valueOf(startTime));
                    prepareCheckSum.setTime(4, java.sql.Time.valueOf(endTime));
                    checkSumSQLList.add(prepareCheckSum);

                    String insertSQL = "INSERT INTO Class_Enrolment VALUES (?,?,?,?,?)";
                    PreparedStatement prepareInsert = connection.prepareStatement(insertSQL);
                    prepareInsert.setInt(1, trainerID);
                    prepareInsert.setDate(2, java.sql.Date.valueOf(dateRecord));
                    prepareInsert.setTime(3, java.sql.Time.valueOf(startTime));
                    prepareInsert.setTime(4, java.sql.Time.valueOf(endTime));
                    prepareInsert.setString(5, email);
                    insertSQLList.add(prepareInsert);

                    capacityList.add(capacity);
                }
                rs.close();
                System.out.println("Which class do you want to join?");
                int choice = input.nextInt();
                input.nextLine();

                ResultSet result = checkSumSQLList.get(choice - 1).executeQuery();
                result.next();

                //update to the Class_enrolement table
                int sum = result.getInt("Sum");
                int capacity = capacityList.get(choice - 1);

                if (sum < capacity) {
                    //if capacity<number or enrolments, insert
                    insertSQLList.get(choice - 1).executeUpdate();
                    System.out.println("Successful to join the group fitness class.");
                } else {
                    System.out.println("Failed to join the group fitness class. Class is full.");
                }

                for (int k = 0; k < insertSQLList.size(); k++) {
                    insertSQLList.get(k).close();
                    checkSumSQLList.get(k).close();
                }


            } catch (SQLException e) {
                System.out.println("Failed to book a group fitness class.");
                e.printStackTrace();
            }
        }catch (SQLException e) {
            System.out.println("Failed to book a group fitness class.");
            e.printStackTrace();
        }
    }

    public static void setAvailability(Connection connection, Scanner input, int id){
        String querySQL="SELECT * FROM Availabilities WHERE trainer_ID=? AND date_of_record>=?";
        String today = LocalDate.now().toString();
        try (PreparedStatement ps=connection.prepareStatement(querySQL)){
            ps.setInt(1,id);
            ps.setDate(2,java.sql.Date.valueOf(today));
            ResultSet rs=ps.executeQuery();
            //print out the current availabilities
            while (rs.next()){
                int trainerID=rs.getInt("trainer_ID");
                String dateRecord=rs.getString("date_of_record");
                String startTime=rs.getString("start_time");
                String endTime=rs.getString("end_time");
                String pt_gf=rs.getString("PT_or_GF");
                boolean isBooked= rs.getBoolean("isBooked");
                System.out.println(String.format("Trainer ID: %d, Date: %s, Start Time: %s, End Time: %s, PT/GF: %s, isBooked: %b",trainerID,dateRecord,startTime,endTime,pt_gf,isBooked));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        //insert new availability
        System.out.println("Please add a new availability");
        System.out.println("Add a date today or after today (yyyy-mm-dd)");
        String date=input.nextLine();
        System.out.println("Choose a starting time (hh:mm:ss)");
        String startTime=input.nextLine();
        System.out.println("Choose an ending time (hh:mm:ss)");
        String endTime=input.nextLine();
        System.out.println("Are you available for personal training (PT) or group fitness (GF)?");
        String pt_gf=input.nextLine();
        String inserSQL="INSERT INTO Availabilities (trainer_ID, date_of_record, start_time, end_time, PT_or_GF) VALUES (?,?,?,?,?)";
        try (PreparedStatement prepare=connection.prepareStatement(inserSQL)) {
            prepare.setInt(1, id);
            prepare.setDate(2, java.sql.Date.valueOf(date));
            prepare.setTime(3, java.sql.Time.valueOf(startTime));
            prepare.setTime(4, java.sql.Time.valueOf(endTime));
            prepare.setString(5, pt_gf);
            prepare.executeUpdate();
            System.out.println("Successful to add the availability.");
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public static void scheduleView(Connection connection, Scanner input, int id){
        //See the upcoming sessions
        String querySQL="SELECT date_of_record, start_time, end_time, PT_or_GF FROM Availabilities WHERE trainer_id=? and date_of_record>=? AND isBooked=?";
        String today = LocalDate.now().toString();
        try (PreparedStatement ps=connection.prepareStatement(querySQL)) {
            ps.setInt(1, id);
            ps.setDate(2, java.sql.Date.valueOf(today));
            ps.setBoolean(3, true);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String date = rs.getString("date_of_record");
                String startTime = rs.getString("start_time");
                String endTime = rs.getString("end_time");
                String pt_gf = rs.getString("PT_or_GF");
                System.out.println(String.format("Date: %s, Start Time: %s, End Time: %s, PT/GF: %s", date, startTime, endTime, pt_gf));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public static void bookRoom(Connection connection, Scanner input, int id){
        while (true) {
            System.out.println("Do you want to book a room for individual training session or group fitness class");
            System.out.println("1. Individual Training Session");
            System.out.println("2. Group Fitness Class");
            System.out.println("3. Exit");
            int option = input.nextInt();
            input.nextLine();
            if (option == 1) {
                String querySQL="SELECT * FROM Individual_Training_Sessions WHERE room_number IS NULL";
                try (PreparedStatement ps=connection.prepareStatement(querySQL)){
                    ResultSet rs=ps.executeQuery();
                    int index=0;
                    //this arraylist to store the queries for suitable rooms
                    ArrayList<ResultSet> roomAvailableList=new ArrayList<>();
                    ArrayList<Integer> trainerIDList=new ArrayList<>();
                    //list all the individual training sessions without a room
                    while (rs.next()){
                        int trainerID=rs.getInt("trainer_ID");
                        String dateRecord=rs.getString("date_of_record");
                        String startTime=rs.getString("start_time");
                        String endTime=rs.getString("end_time");
                        int capacity=rs.getInt("capacity");
                        System.out.println(String.format("%d. Trainer ID: %d, Date: %s, Start Time: %s, End Time: %s, Capacity: %d",index+1, trainerID, dateRecord,startTime,endTime,capacity));
                        String searchQuerySQL="SELECT rb.* FROM Room r, Room_Booking rb WHERE r.capacity>=? AND r.room_number=rb.room_number AND rb.date_of_record=? AND start_time=? AND end_time=? AND isBooked=?";
                        index++;
                        PreparedStatement prepare=connection.prepareStatement(searchQuerySQL);
                        prepare.setInt(1,2);
                        prepare.setDate(2,java.sql.Date.valueOf(dateRecord));
                        prepare.setTime(3,java.sql.Time.valueOf(startTime));
                        prepare.setTime(4,java.sql.Time.valueOf(endTime));
                        prepare.setBoolean(5,false);
                        ResultSet result=prepare.executeQuery();
                        //add the result set to the arraylist
                        roomAvailableList.add(result);
                        trainerIDList.add(trainerID);
                    }
                    System.out.println("Which individual training session do you want to assign a room for?");
                    int ITSOption=input.nextInt();
                    input.nextLine();
                    ResultSet r=roomAvailableList.get(ITSOption-1);
                    int trainerID=trainerIDList.get(ITSOption-1);
                    ArrayList<PreparedStatement> updateRBList=new ArrayList<>();
                    ArrayList<PreparedStatement> updateITSList=new ArrayList<>();
                    int order=0;
                    //this list all the available room bookings
                    while (r.next()){
                        int roomNumber=r.getInt("room_number");
                        String dateRecord=r.getString("date_of_record");
                        String startTime=r.getString("start_time");
                        String endTime=r.getString("end_time");
                        boolean isBooked=r.getBoolean("isBooked");
                        //need to list all the rooms available
                        System.out.println(String.format("%d. Room Number: %d, Date: %s, Start Time: %s, End Time %s, isBooked: %b",order+1, roomNumber,dateRecord,startTime,endTime,isBooked));
                        order++;
                        String updateRBSQL="UPDATE Room_Booking SET isBooked=?, staff=?, trainer=? WHERE room_number=? AND date_of_record=? AND start_time=? AND end_time=?";
                        PreparedStatement pstm=connection.prepareStatement(updateRBSQL);
                        pstm.setBoolean(1,true);
                        pstm.setInt(2,id);
                        pstm.setInt(3,trainerID);
                        pstm.setInt(4,roomNumber);
                        pstm.setDate(5,java.sql.Date.valueOf(dateRecord));
                        pstm.setTime(6,java.sql.Time.valueOf(startTime));
                        pstm.setTime(7,java.sql.Time.valueOf(endTime));
                        updateRBList.add(pstm);

                        String updateITSSQL="UPDATE Individual_Training_Sessions SET room_number=? WHERE trainer_ID=? AND date_of_record=? AND start_time=? AND end_time=?";
                        PreparedStatement pst=connection.prepareStatement(updateITSSQL);
                        pst.setInt(1,roomNumber);
                        pst.setInt(2,trainerID);
                        pst.setDate(3,java.sql.Date.valueOf(dateRecord));
                        pst.setTime(4,java.sql.Time.valueOf(startTime));
                        pst.setTime(5,java.sql.Time.valueOf(endTime));
                        updateITSList.add(pst);
                    }
                    System.out.println("Which room do you want to book?");
                    int roomOption=input.nextInt();
                    input.nextLine();
                    updateRBList.get(roomOption-1).executeUpdate();
                    updateITSList.get(roomOption-1).executeUpdate();
                    for (int k=1; k<updateRBList.size();k++){
                        updateRBList.get(k).close();
                        updateITSList.get(k).close();
                    }
                    System.out.println("Room is booked successfully for your individual training session.");
                }catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            }else if (option == 2) {
                //book a room for group fitness class
                String querySQL="SELECT * FROM Group_Fitness_Classes WHERE room_number IS NULL";
                try (PreparedStatement ps=connection.prepareStatement(querySQL)){
                    ResultSet rs=ps.executeQuery();
                    int index=0;
                    //this arraylist to store the queries for suitable rooms
                    ArrayList<ResultSet> roomAvailableList=new ArrayList<>();
                    ArrayList<Integer> trainerIDList=new ArrayList<>();
                    //list all the group fitness classes without a room
                    while (rs.next()){
                        int trainerID=rs.getInt("trainer_ID");
                        String dateRecord=rs.getString("date_of_record");
                        String startTime=rs.getString("start_time");
                        String endTime=rs.getString("end_time");
                        int capacity=rs.getInt("capacity");
                        System.out.println(String.format("%d. Trainer ID: %d, Date: %s, Start Time: %s, End Time: %s, Capacity: %d",index+1, trainerID, dateRecord,startTime,endTime,capacity));
                        String searchQuerySQL="SELECT rb.* FROM Room r, Room_Booking rb WHERE r.capacity>=? AND r.room_number=rb.room_number AND rb.date_of_record=? AND start_time=? AND end_time=? AND isBooked=?";
                        index++;
                        PreparedStatement prepare=connection.prepareStatement(searchQuerySQL);
                        prepare.setInt(1,capacity);
                        prepare.setDate(2,java.sql.Date.valueOf(dateRecord));
                        prepare.setTime(3,java.sql.Time.valueOf(startTime));
                        prepare.setTime(4,java.sql.Time.valueOf(endTime));
                        prepare.setBoolean(5,false);
                        ResultSet result=prepare.executeQuery();
                        //add the result set to the arraylist
                        roomAvailableList.add(result);
                        trainerIDList.add(trainerID);
                    }
                    System.out.println("Which group fitness class do you want to assign a room for?");
                    int GFCOption=input.nextInt();
                    input.nextLine();
                    ResultSet r=roomAvailableList.get(GFCOption-1);
                    int trainerID=trainerIDList.get(GFCOption-1);
                    ArrayList<PreparedStatement> updateRBList=new ArrayList<>();
                    ArrayList<PreparedStatement> updateITSList=new ArrayList<>();
                    int order=0;
                    //this list all the available room bookings
                    while (r.next()){
                        int roomNumber=r.getInt("room_number");
                        String dateRecord=r.getString("date_of_record");
                        String startTime=r.getString("start_time");
                        String endTime=r.getString("end_time");
                        boolean isBooked=r.getBoolean("isBooked");
                        //need to list all the rooms available
                        System.out.println(String.format("%d. Room Number: %d, Date: %s, Start Time: %s, End Time %s, isBooked: %b",order+1, roomNumber,dateRecord,startTime,endTime,isBooked));
                        order++;
                        String updateRBSQL="UPDATE Room_Booking SET isBooked=?, staff=?, trainer=? WHERE room_number=? AND date_of_record=? AND start_time=? AND end_time=?";
                        PreparedStatement pstm=connection.prepareStatement(updateRBSQL);
                        pstm.setBoolean(1,true);
                        pstm.setInt(2,id);
                        pstm.setInt(3,trainerID);
                        pstm.setInt(4,roomNumber);
                        pstm.setDate(5,java.sql.Date.valueOf(dateRecord));
                        pstm.setTime(6,java.sql.Time.valueOf(startTime));
                        pstm.setTime(7,java.sql.Time.valueOf(endTime));
                        updateRBList.add(pstm);

                        String updateITSSQL="UPDATE Group_Fitness_Classes SET room_number=? WHERE trainer_ID=? AND date_of_record=? AND start_time=? AND end_time=?";
                        PreparedStatement pst=connection.prepareStatement(updateITSSQL);
                        pst.setInt(1,roomNumber);
                        pst.setInt(2,trainerID);
                        pst.setDate(3,java.sql.Date.valueOf(dateRecord));
                        pst.setTime(4,java.sql.Time.valueOf(startTime));
                        pst.setTime(5,java.sql.Time.valueOf(endTime));
                        updateITSList.add(pst);
                    }
                    System.out.println("Which room do you want to book?");
                    int roomOption=input.nextInt();
                    input.nextLine();
                    updateRBList.get(roomOption-1).executeUpdate();
                    updateITSList.get(roomOption-1).executeUpdate();
                    for (int k=1; k<updateRBList.size();k++){
                        updateRBList.get(k).close();
                        updateITSList.get(k).close();
                    }
                    System.out.println("Room is booked successfully for your group fitness class.");
                }catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            }else if (option == 3) {
                break;
            }else{
                System.out.println("Please enter a number 1 or 3.");
            }
        }
    }
    public static void defineClass(Connection connection, Scanner input, int id){
        while (true){
            System.out.println("1. Define a group fitness class");
            System.out.println("2. Exit");
            int option = input.nextInt();
            input.nextLine();
            if (option==1){
                System.out.println("What is the trainer ID of the trainer?");
                int trainerID = input.nextInt();
                input.nextLine();
                String existSQL = "SELECT EXISTS (SELECT 1 FROM Trainers WHERE trainer_ID=?)";
                try (PreparedStatement pst = connection.prepareStatement(existSQL)) {
                    pst.setInt(1, trainerID);
                    ResultSet r = pst.executeQuery();
                    boolean exists = false;
                    if (r.next()) {
                        exists = r.getBoolean(1); // <- read the EXISTS result
                    }
                    r.close();
                    if (!exists) {
                        System.out.println("Trainer does not exist, please register the trainer");
                        System.out.println("First Name: ");
                        String firstName = input.nextLine();
                        System.out.println("Last Name:");
                        String lastName = input.nextLine();
                        System.out.println("Gender (M/F):");
                        String gender = input.nextLine();
                        System.out.println("Date of Birth (yyyy-mm-dd):");
                        String dateBirth = input.nextLine();
                        System.out.println("Email: ");
                        String email = input.nextLine();

                        String insertTrainerSQL = "INSERT INTO Trainers (first_name,last_name,gender,date_of_birth,email) VALUES (?,?,?,?,?)";
                        PreparedStatement ps = connection.prepareStatement(insertTrainerSQL);
                        ps.setString(1, firstName);
                        ps.setString(2, lastName);
                        ps.setString(3, gender);
                        ps.setDate(4, java.sql.Date.valueOf(dateBirth));
                        ps.setString(5, email);
                        ps.executeUpdate();
                        System.out.println("Insertion to the Trainer is successful!");
                        continue;
                    }else{
                        //trainerID exists
                        System.out.println("What should be the name of the class?");
                        String className=input.nextLine();
                        System.out.println("What is the maximal capacity of this class (0-60)?");
                        int capacity=input.nextInt();
                        input.nextLine();

                        String querySQL="SELECT * FROM Availabilities WHERE trainer_ID=? AND PT_or_GF=? AND isBooked=?";
                        PreparedStatement ps=connection.prepareStatement(querySQL);
                        ps.setInt(1,trainerID);
                        ps.setString(2,"GF");
                        ps.setBoolean(3,false);
                        //all this trainer's availabilities for GF
                        ResultSet rs=ps.executeQuery();
                        int index=0;
                        ArrayList<PreparedStatement> psList=new ArrayList<>();
                        while (rs.next()){
                            String dateRecord=rs.getString("date_of_record");
                            String startTime=rs.getString("start_time");
                            String endTime=rs.getString("end_time");
                            System.out.println(String.format("%d. Date: %s, Start Time: %s, End Time: %s",index+1, dateRecord,startTime,endTime));
                            String insertSQL="INSERT INTO Group_Fitness_Classes (trainer_ID,date_of_record,start_time,end_time,class_name,capacity) VALUES (?,?,?,?,?,?)";
                            PreparedStatement p=connection.prepareStatement(insertSQL);
                            p.setInt(1,trainerID);
                            p.setDate(2,java.sql.Date.valueOf(dateRecord));
                            p.setTime(3,java.sql.Time.valueOf(startTime));
                            p.setTime(4,java.sql.Time.valueOf(endTime));
                            p.setString(5,className);
                            p.setInt(6,capacity);
                            psList.add(p);
                            index++;
                        }
                        System.out.println("Which time slot do you want?");
                        int choice=input.nextInt();
                        input.nextLine();
                        psList.get(choice-1).executeUpdate();
                        System.out.println("The class has been defined successfully.");
                    }
                }catch (SQLException e) {
                    System.out.println("Failed to define a class.");
                    e.printStackTrace();
                }
            }else if (option==2){
                break;
            }else{
                System.out.println("Please enter number 1 or 2.");
            }
        }



    }
}